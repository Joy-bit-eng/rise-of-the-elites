import { defineConfig } from 'vite';

export default defineConfig({
  base: '/Rise-Of-The-Elites--/', // use your GitHub repo name
  build: {
    outDir: 'dist'
  }
});
